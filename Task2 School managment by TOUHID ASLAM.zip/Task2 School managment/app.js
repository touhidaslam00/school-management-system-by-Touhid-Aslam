// ============================================
// میمن پبلک سکول - سکول مینیجمنٹ سسٹم
// Memon Public School - Management System
// ============================================

// Global Data Store
let schoolData = {
    students: [],
    teachers: [],
    courses: [],
    attendance: [],
    grades: [],
    schedules: [],
    fees: [],
    activities: [],
    events: []
};

// User Authentication State
let currentUser = {
    isLoggedIn: false,
    username: '',
    role: ''
};

// Demo credentials
const demoUsers = {
    admin: { password: 'admin123', role: 'admin', name: 'Admin' },
    teacher: { password: 'teacher123', role: 'teacher', name: 'Teacher' },
    student: { password: 'student123', role: 'student', name: 'Student' }
};

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatus();
    setupEventListeners();
    loadSampleData();
    renderDashboard();
    populateDropdowns();
});

// ============================================
// AUTHENTICATION
// ============================================

function checkLoginStatus() {
    const savedUser = localStorage.getItem('memonSchoolUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        if (currentUser.isLoggedIn) {
            showMainApp();
            updateUserUI();
        } else {
            showLoginModal();
        }
    } else {
        showLoginModal();
    }
}

function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;
    const role = document.getElementById('loginRole').value;
    
    // Check credentials
    const user = demoUsers[username];
    
    if (user && user.password === password && user.role === role) {
        currentUser = {
            isLoggedIn: true,
            username: username,
            role: role,
            name: user.name
        };
        
        localStorage.setItem('memonSchoolUser', JSON.stringify(currentUser));
        
        closeModal(document.getElementById('loginModal'));
        showMainApp();
        updateUserUI();
        
        addActivity('🔐', `User logged in: ${user.name} | ${role}`);
        showToast('Welcome back! | خوش آمدید!', 'success');
    } else {
        showToast('Invalid credentials! | غلط معلومات!', 'error');
        shakeElement(document.getElementById('loginForm'));
    }
}

function handleLogout() {
    // Close dropdown first
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) dropdown.classList.remove('active');
    
    // Show logout confirmation modal
    const logoutModal = document.getElementById('logoutModal');
    if (logoutModal) {
        logoutModal.classList.add('active');
    }
}

function confirmLogout() {
    const userName = currentUser.name || currentUser.username;
    
    currentUser = {
        isLoggedIn: false,
        username: '',
        role: ''
    };
    
    localStorage.removeItem('memonSchoolUser');
    
    closeModal(document.getElementById('logoutModal'));
    hideMainApp();
    showLoginModal();
    
    addActivity('🚪', `User logged out: ${userName}`);
    showToast('Logged out successfully! | خدا حافظ!', 'info');
}

function showLoginModal() {
    const loginModal = document.getElementById('loginModal');
    if (loginModal) {
        loginModal.classList.add('active');
        // Remove close button for login modal
        const closeBtn = loginModal.querySelector('.modal-close');
        if (closeBtn) closeBtn.style.display = 'none';
    }
}

function showMainApp() {
    const appContainer = document.querySelector('.container');
    if (appContainer) {
        appContainer.classList.add('logged-in');
    }
}

function hideMainApp() {
    const appContainer = document.querySelector('.container');
    if (appContainer) {
        appContainer.classList.remove('logged-in');
    }
}

function updateUserUI() {
    const userNameEl = document.getElementById('dropdownUserName');
    const userRoleEl = document.getElementById('dropdownUserRole');
    const dropdownAvatar = document.getElementById('dropdownAvatar');
    
    if (currentUser.name) {
        if (userNameEl) userNameEl.textContent = currentUser.name;
        if (dropdownAvatar) dropdownAvatar.textContent = currentUser.name.charAt(0).toUpperCase();
    } else {
        if (userNameEl) userNameEl.textContent = currentUser.username;
        if (dropdownAvatar) dropdownAvatar.textContent = currentUser.username.charAt(0).toUpperCase();
    }
    
    if (userRoleEl) userRoleEl.textContent = currentUser.role;
    
    // Update header user name
    const headerUserName = document.querySelector('.user-name');
    if (headerUserName) {
        const name = currentUser.name || currentUser.username;
        headerUserName.textContent = `${name} | ${currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}`;
    }
    
    // Update header avatar
    const headerAvatar = document.querySelector('.user-avatar');
    if (headerAvatar) {
        const name = currentUser.name || currentUser.username;
        headerAvatar.textContent = name.charAt(0).toUpperCase();
    }
}

function toggleUserDropdown() {
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) {
        dropdown.classList.toggle('active');
    }
}

function showProfile() {
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) dropdown.classList.remove('active');
    showToast('Profile page coming soon!', 'info');
}

function showSettings() {
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) dropdown.classList.remove('active');
    showToast('Settings page coming soon!', 'info');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    const dropdown = document.getElementById('userDropdown');
    const userProfile = document.querySelector('.user-profile');
    
    if (dropdown && dropdown.classList.contains('active')) {
        if (!dropdown.contains(e.target) && !userProfile?.contains(e.target)) {
            dropdown.classList.remove('active');
        }
    }
});

// ============================================
// INITIALIZATION
// ============================================

function initializeApp() {
    loadDataFromStorage();
    setDefaultDate();
    updateAllStats();
}

function loadDataFromStorage() {
    const savedData = localStorage.getItem('memonSchoolData');
    if (savedData) {
        schoolData = JSON.parse(savedData);
    }
}

function saveDataToStorage() {
    localStorage.setItem('memonSchoolData', JSON.stringify(schoolData));
}

function setDefaultDate() {
    const dateInput = document.getElementById('attendanceDate');
    if (dateInput) {
        dateInput.valueAsDate = new Date();
    }
}

// ============================================
// EVENT LISTENERS
// ============================================

function setupEventListeners() {
    // Navigation
    setupNavigation();
    
    // Mobile Menu Toggle
    setupMobileMenu();
    
    // Modal Controls
    setupModalControls();
    
    // Form Submissions
    setupFormSubmissions();
    
    // Search
    setupSearch();
    
    // Notification Button
    setupNotifications();
    
    // User Profile Dropdown
    setupUserProfile();
}

// User Profile Setup
function setupUserProfile() {
    const userProfile = document.querySelector('.user-profile');
    if (userProfile) {
        userProfile.addEventListener('click', toggleUserDropdown);
    }
}

// Shake Animation for errors
function shakeElement(element) {
    if (element) {
        element.style.animation = 'none';
        element.offsetHeight; // Trigger reflow
        element.style.animation = 'shake 0.5s ease';
    }
}

// Add shake keyframes dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-10px); }
        20%, 40%, 60%, 80% { transform: translateX(10px); }
    }
`;
document.head.appendChild(style);

// Navigation Setup
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            navigateToSection(section);
            
            // Update active state
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Mobile Menu
function setupMobileMenu() {
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
        
        // Close sidebar when clicking outside
        document.addEventListener('click', function(e) {
            if (window.innerWidth <= 992) {
                if (!sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });
    }
}

// Modal Controls
function setupModalControls() {
    // Close buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            closeModal(modal);
        });
    });
    
    // Cancel buttons
    document.querySelectorAll('[data-modal]').forEach(btn => {
        btn.addEventListener('click', function() {
            const modalId = this.getAttribute('data-modal');
            closeModal(document.getElementById(modalId));
        });
    });
    
    // Click outside to close
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal(this);
            }
        });
    });
    
    // Add buttons
    document.getElementById('addStudentBtn')?.addEventListener('click', () => openModal('studentModal', 'Add Student | طالب علم شامل کریں'));
    document.getElementById('addTeacherBtn')?.addEventListener('click', () => openModal('teacherModal', 'Add Teacher | استاد شامل کریں'));
    document.getElementById('addCourseBtn')?.addEventListener('click', () => openModal('courseModal', 'Add Course | کورس شامل کریں'));
    document.getElementById('addFeeBtn')?.addEventListener('click', () => openModal('feeModal', 'Add Fee Record | فیس ریکارڈ شامل کریں'));
    document.getElementById('addScheduleBtn')?.addEventListener('click', () => openModal('scheduleModal', 'Add Class | کلاس شامل کریں'));
}

// Form Submissions
function setupFormSubmissions() {
    // Login Form
    document.getElementById('loginForm')?.addEventListener('submit', handleLogin);
    
    // Student Form
    document.getElementById('studentForm')?.addEventListener('submit', handleStudentSubmit);
    
    // Teacher Form
    document.getElementById('teacherForm')?.addEventListener('submit', handleTeacherSubmit);
    
    // Course Form
    document.getElementById('courseForm')?.addEventListener('submit', handleCourseSubmit);
    
    // Fee Form
    document.getElementById('feeForm')?.addEventListener('submit', handleFeeSubmit);
    
    // Schedule Form
    document.getElementById('scheduleForm')?.addEventListener('submit', handleScheduleSubmit);
}

// Search
function setupSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            if (searchTerm.length > 2) {
                searchData(searchTerm);
            }
        });
    }
}

// Notifications
function setupNotifications() {
    const notificationBtn = document.getElementById('notificationBtn');
    if (notificationBtn) {
        notificationBtn.addEventListener('click', function() {
            showToast('Notifications | اطلاعات: 3 new notifications', 'info');
        });
    }
}

// ============================================
// NAVIGATION
// ============================================

function navigateToSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        
        // Refresh section data
        switch (sectionId) {
            case 'dashboard':
                renderDashboard();
                break;
            case 'students':
                renderStudentsTable();
                break;
            case 'teachers':
                renderTeachersTable();
                break;
            case 'courses':
                renderCoursesGrid();
                break;
            case 'attendance':
                renderAttendanceSection();
                break;
            case 'grades':
                renderGradesSection();
                break;
            case 'schedule':
                renderScheduleSection();
                break;
            case 'fees':
                renderFeesSection();
                break;
        }
    }
}

// ============================================
// MODAL FUNCTIONS
// ============================================

function openModal(modalId, title) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        const titleElement = modal.querySelector('.modal-header h3');
        if (titleElement) {
            titleElement.textContent = title;
        }
        
        // Reset form
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    }
}

function closeModal(modal) {
    if (modal) {
        modal.classList.remove('active');
    }
}

// ============================================
// FORM HANDLERS
// ============================================

function handleStudentSubmit(e) {
    e.preventDefault();
    
    const student = {
        id: generateId('STU'),
        name: document.getElementById('studentName').value,
        email: document.getElementById('studentEmail').value,
        phone: document.getElementById('studentPhone').value,
        class: document.getElementById('studentClass').value,
        city: document.getElementById('studentCity').value,
        fatherName: document.getElementById('studentFatherName')?.value || '',
        cnic: document.getElementById('studentCNIC')?.value || '',
        admissionDate: new Date().toISOString().split('T')[0]
    };
    
    schoolData.students.push(student);
    saveDataToStorage();
    
    addActivity('👨‍🎓', `New student enrolled: ${student.name} | ${student.class}`);
    showToast('Student added successfully! | طالب علم شامل ہو گیا!', 'success');
    
    closeModal(document.getElementById('studentModal'));
    renderStudentsTable();
    populateDropdowns();
    updateAllStats();
}

function handleTeacherSubmit(e) {
    e.preventDefault();
    
    const teacher = {
        id: generateId('TCH'),
        name: document.getElementById('teacherName').value,
        email: document.getElementById('teacherEmail').value,
        subject: document.getElementById('teacherSubject').value,
        phone: document.getElementById('teacherPhone').value,
        qualification: document.getElementById('teacherQualification')?.value || '',
        experience: document.getElementById('teacherExperience')?.value || '',
        salary: document.getElementById('teacherSalary')?.value || ''
    };
    
    schoolData.teachers.push(teacher);
    saveDataToStorage();
    
    addActivity('👨‍🏫', `New teacher added: ${teacher.name} | ${teacher.subject}`);
    showToast('Teacher added successfully! | استاد شامل ہو گیا!', 'success');
    
    closeModal(document.getElementById('teacherModal'));
    renderTeachersTable();
    populateDropdowns();
    updateAllStats();
}

function handleCourseSubmit(e) {
    e.preventDefault();
    
    const course = {
        id: generateId('CRS'),
        name: document.getElementById('courseName').value,
        code: document.getElementById('courseCode').value,
        teacherId: document.getElementById('courseTeacher').value,
        credits: document.getElementById('courseCredits').value,
        classLevel: document.getElementById('courseClass')?.value || '',
        description: document.getElementById('courseDescription')?.value || ''
    };
    
    schoolData.courses.push(course);
    saveDataToStorage();
    
    addActivity('📚', `New course added: ${course.name}`);
    showToast('Course added successfully! | کورس شامل ہو گیا!', 'success');
    
    closeModal(document.getElementById('courseModal'));
    renderCoursesGrid();
    populateDropdowns();
    updateAllStats();
}

function handleFeeSubmit(e) {
    e.preventDefault();
    
    const fee = {
        id: generateId('INV'),
        studentId: document.getElementById('feeStudent').value,
        amount: parseFloat(document.getElementById('feeAmount').value),
        dueDate: document.getElementById('feeDueDate').value,
        feeType: document.getElementById('feeType')?.value || 'tuition',
        status: 'pending',
        description: document.getElementById('feeDescription')?.value || ''
    };
    
    schoolData.fees.push(fee);
    saveDataToStorage();
    
    addActivity('💰', `Fee invoice created for student`);
    showToast('Fee record added successfully! | فیس ریکارڈ شامل ہو گیا!', 'success');
    
    closeModal(document.getElementById('feeModal'));
    renderFeesSection();
}

function handleScheduleSubmit(e) {
    e.preventDefault();
    
    const schedule = {
        id: generateId('SCH'),
        day: document.getElementById('scheduleDay').value,
        time: document.getElementById('scheduleTime').value,
        courseId: document.getElementById('scheduleCourse').value,
        room: document.getElementById('scheduleRoom').value,
        class: document.getElementById('scheduleClass')?.value || ''
    };
    
    schoolData.schedules.push(schedule);
    saveDataToStorage();
    
    addActivity('🕐', `New class scheduled: ${schedule.day} at ${schedule.time}`);
    showToast('Class scheduled successfully! | کلاس کا پروگرام بنا دیا گیا!', 'success');
    
    closeModal(document.getElementById('scheduleModal'));
    renderScheduleSection();
}

// ============================================
// RENDER FUNCTIONS
// ============================================

// Dashboard
function renderDashboard() {
    updateAllStats();
    renderActivities();
    renderEvents();
}

function updateAllStats() {
    // Students
    const studentsEl = document.getElementById('totalStudents');
    if (studentsEl) {
        animateCounter(studentsEl, schoolData.students.length);
    }
    
    // Teachers
    const teachersEl = document.getElementById('totalTeachers');
    if (teachersEl) {
        animateCounter(teachersEl, schoolData.teachers.length);
    }
    
    // Courses
    const coursesEl = document.getElementById('totalCourses');
    if (coursesEl) {
        animateCounter(coursesEl, schoolData.courses.length);
    }
    
    // Attendance
    const attendanceEl = document.getElementById('todayAttendance');
    if (attendanceEl) {
        const today = new Date().toISOString().split('T')[0];
        const todayAttendance = schoolData.attendance.filter(a => a.date === today);
        const presentCount = todayAttendance.filter(a => a.status === 'present').length;
        const totalCount = todayAttendance.length;
        const percentage = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;
        attendanceEl.textContent = percentage + '%';
    }
}

function animateCounter(element, target) {
    element.textContent = target;
}

// Activities
function renderActivities() {
    const activityList = document.getElementById('activityList');
    if (activityList) {
        activityList.innerHTML = schoolData.activities.slice(0, 6).map(activity => `
            <li>
                <div class="activity-icon">${activity.icon}</div>
                <div class="activity-content">
                    <p>${activity.text}</p>
                    <span>🕐 ${activity.time}</span>
                </div>
            </li>
        `).join('');
    }
}

// Events
function renderEvents() {
    const eventList = document.getElementById('eventList');
    if (eventList) {
        eventList.innerHTML = schoolData.events.map(event => `
            <li>
                <div class="activity-icon">📅</div>
                <div class="event-content">
                    <p>${event.text}</p>
                    <span>📆 ${event.date}</span>
                </div>
            </li>
        `).join('');
    }
}

// Students Table
function renderStudentsTable() {
    const tbody = document.getElementById('studentsTableBody');
    if (tbody) {
        if (schoolData.students.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:30px;">No students found | کوئی طالب علم نہیں ملا</td></tr>';
            return;
        }
        
        tbody.innerHTML = schoolData.students.map(student => `
            <tr>
                <td>${student.id}</td>
                <td>${student.name}</td>
                <td>${student.email}</td>
                <td>${student.phone}</td>
                <td>${student.class}</td>
                <td>${student.city || '-'}</td>
                <td class="actions">
                    <button class="btn btn-sm btn-primary" onclick="editStudent('${student.id}')">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteStudent('${student.id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }
}

// Teachers Table
function renderTeachersTable() {
    const tbody = document.getElementById('teachersTableBody');
    if (tbody) {
        if (schoolData.teachers.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:30px;">No teachers found | کوئی استاد نہیں ملا</td></tr>';
            return;
        }
        
        tbody.innerHTML = schoolData.teachers.map(teacher => `
            <tr>
                <td>${teacher.id}</td>
                <td>${teacher.name}</td>
                <td>${teacher.email}</td>
                <td>${teacher.subject}</td>
                <td>${teacher.phone}</td>
                <td class="actions">
                    <button class="btn btn-sm btn-primary" onclick="editTeacher('${teacher.id}')">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteTeacher('${teacher.id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }
}

// Courses Grid
function renderCoursesGrid() {
    const coursesGrid = document.getElementById('coursesGrid');
    if (coursesGrid) {
        if (schoolData.courses.length === 0) {
            coursesGrid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:30px;">No courses found | کوئی کورس نہیں ملا</div>';
            return;
        }
        
        coursesGrid.innerHTML = schoolData.courses.map(course => {
            const teacher = schoolData.teachers.find(t => t.id === course.teacherId);
            return `
                <div class="course-card">
                    <div class="course-header">
                        <h3>${course.name}</h3>
                        <span class="code">${course.code}</span>
                    </div>
                    <div class="course-body">
                        <p>📚 Teacher: ${teacher ? teacher.name : 'N/A'}</p>
                        <p>🏫 Class: ${course.classLevel || 'All'}</p>
                        <p>📊 Credits: ${course.credits}</p>
                        <span class="credits">${course.credits} Credits</span>
                    </div>
                </div>
            `;
        }).join('');
    }
}

// Attendance Section
function renderAttendanceSection() {
    renderAttendanceTable();
    populateAttendanceControls();
}

function renderAttendanceTable() {
    const tbody = document.getElementById('attendanceTableBody');
    if (tbody) {
        const selectedClass = document.getElementById('attendanceClass')?.value;
        let students = schoolData.students;
        
        if (selectedClass) {
            students = students.filter(s => s.class === selectedClass);
        }
        
        if (students.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:30px;">No students found | کوئی طالب علم نہیں ملا</td></tr>';
            return;
        }
        
        tbody.innerHTML = students.map(student => {
            const today = new Date().toISOString().split('T')[0];
            const existingAttendance = schoolData.attendance.find(a => a.studentId === student.id && a.date === today);
            const status = existingAttendance ? existingAttendance.status : 'present';
            
            return `
                <tr>
                    <td>${student.id}</td>
                    <td>${student.name}</td>
                    <td>
                        <select class="attendance-status" data-student="${student.id}">
                            <option value="present" ${status === 'present' ? 'selected' : ''}>Present | حاضر</option>
                            <option value="absent" ${status === 'absent' ? 'selected' : ''}>Absent | غائب</option>
                            <option value="late" ${status === 'late' ? 'selected' : ''}>Late | دیر سے</option>
                        </select>
                    </td>
                    <td class="actions">
                        <button class="btn btn-sm btn-success" onclick="saveAttendance('${student.id}')">Save</button>
                    </td>
                </tr>
            `;
        }).join('');
    }
}

function populateAttendanceControls() {
    const classSelect = document.getElementById('attendanceClass');
    if (classSelect && classSelect.options.length <= 1) {
        // Get unique classes
        const classes = [...new Set(schoolData.students.map(s => s.class))];
        classSelect.innerHTML = '<option value="">Select Class | جماعت select کریں</option>';
        classes.forEach(cls => {
            classSelect.innerHTML += `<option value="${cls}">${cls}</option>`;
        });
    }
}

// Grades Section
function renderGradesSection() {
    renderGradesTable();
    populateGradeControls();
}

function renderGradesTable() {
    const tbody = document.getElementById('gradesTableBody');
    if (tbody) {
        const students = schoolData.students;
        
        if (students.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:30px;">No students found | کوئی طالب علم نہیں ملا</td></tr>';
            return;
        }
        
        tbody.innerHTML = students.map(student => `
            <tr>
                <td>${student.id}</td>
                <td>${student.name}</td>
                <td>
                    <input type="number" min="0" max="100" placeholder="Score" class="grade-score" data-student="${student.id}" style="width:100px;padding:8px;border:1px solid #ddd;border-radius:5px;">
                </td>
                <td>
                    <select class="grade-grade" data-student="${student.id}" style="padding:8px;border:1px solid #ddd;border-radius:5px;">
                        <option value="">Grade | گریڈ</option>
                        <option value="A+">A+</option>
                        <option value="A">A</option>
                        <option value="B+">B+</option>
                        <option value="B">B</option>
                        <option value="C+">C+</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                        <option value="F">F</option>
                    </select>
                </td>
                <td class="actions">
                    <button class="btn btn-sm btn-success" onclick="saveGrade('${student.id}')">Save</button>
                </td>
            </tr>
        `).join('');
    }
}

function populateGradeControls() {
    const courseSelect = document.getElementById('gradeCourse');
    if (courseSelect && courseSelect.options.length <= 1) {
        courseSelect.innerHTML = '<option value="">Select Course | کورس select کریں</option>';
        schoolData.courses.forEach(course => {
            courseSelect.innerHTML += `<option value="${course.id}">${course.name}</option>`;
        });
    }
}

// Schedule Section
function renderScheduleSection() {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const dayMapping = {
        'Monday': 'mondaySchedule',
        'Tuesday': 'tuesdaySchedule',
        'Wednesday': 'wednesdaySchedule',
        'Thursday': 'thursdaySchedule',
        'Friday': 'fridaySchedule'
    };

    days.forEach(day => {
        const scheduleList = document.getElementById(dayMapping[day]);
        if (scheduleList) {
            const daySchedules = schoolData.schedules
                .filter(s => s.day === day)
                .sort((a, b) => a.time.localeCompare(b.time));
            
            if (daySchedules.length === 0) {
                scheduleList.innerHTML = '<div style="padding:15px;text-align:center;color:#999;">No classes | کوئی کلاس نہیں</div>';
            } else {
                scheduleList.innerHTML = daySchedules.map(schedule => {
                    const course = schoolData.courses.find(c => c.id === schedule.courseId);
                    return `
                        <div class="schedule-item">
                            <div class="time">⏰ ${schedule.time}</div>
                            <div class="course">${course ? course.name : 'N/A'} - ${schedule.room}</div>
                        </div>
                    `;
                }).join('');
            }
        }
    });
}

// Fees Section
function renderFeesSection() {
    renderFeesTable();
    updateFeeSummary();
}

function renderFeesTable() {
    const tbody = document.getElementById('feesTableBody');
    if (tbody) {
        if (schoolData.fees.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:30px;">No fee records found | کوئی فیس ریکارڈ نہیں ملا</td></tr>';
            return;
        }
        
        tbody.innerHTML = schoolData.fees.map(fee => {
            const student = schoolData.students.find(s => s.id === fee.studentId);
            const statusClass = fee.status === 'paid' ? 'status-paid' : fee.status === 'pending' ? 'status-pending' : 'status-overdue';
            const statusText = fee.status === 'paid' ? 'Paid | ادا شدہ' : fee.status === 'pending' ? 'Pending | باقی' : 'Overdue | واجب الادا';
            
            return `
                <tr>
                    <td>${fee.id}</td>
                    <td>${student ? student.name : 'N/A'}</td>
                    <td>Rs. ${fee.amount.toLocaleString()}</td>
                    <td>${fee.dueDate}</td>
                    <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                    <td class="actions">
                        ${fee.status === 'pending' ? `<button class="btn btn-sm btn-success" onclick="markFeePaid('${fee.id}')">Pay</button>` : ''}
                        <button class="btn btn-sm btn-danger" onclick="deleteFee('${fee.id}')">Delete</button>
                    </td>
                </tr>
            `;
        }).join('');
    }
}

function updateFeeSummary() {
    const totalCollected = schoolData.fees.filter(f => f.status === 'paid').reduce((sum, f) => sum + f.amount, 0);
    const totalPending = schoolData.fees.filter(f => f.status === 'pending').reduce((sum, f) => sum + f.amount, 0);
    const totalOverdue = schoolData.fees.filter(f => f.status === 'overdue').reduce((sum, f) => sum + f.amount, 0);
    
    const collectedEl = document.getElementById('totalCollected');
    const pendingEl = document.getElementById('totalPending');
    const overdueEl = document.getElementById('totalOverdue');
    
    if (collectedEl) collectedEl.textContent = `Rs. ${totalCollected.toLocaleString()}`;
    if (pendingEl) pendingEl.textContent = `Rs. ${totalPending.toLocaleString()}`;
    if (overdueEl) overdueEl.textContent = `Rs. ${totalOverdue.toLocaleString()}`;
}

// ============================================
// ACTION FUNCTIONS
// ============================================

function saveAttendance(studentId) {
    const select = document.querySelector(`[data-student="${studentId}"].attendance-status`);
    const status = select?.value;
    const date = document.getElementById('attendanceDate')?.value || new Date().toISOString().split('T')[0];
    
    if (!status) return;
    
    // Remove existing attendance
    schoolData.attendance = schoolData.attendance.filter(a => !(a.studentId === studentId && a.date === date));
    
    // Add new attendance
    schoolData.attendance.push({ studentId, date, status });
    saveDataToStorage();
    
    showToast('Attendance saved! | حاضری محفوظ!', 'success');
}

function saveGrade(studentId) {
    const scoreInput = document.querySelector(`[data-student="${studentId}"].grade-score`);
    const gradeSelect = document.querySelector(`[data-student="${studentId}"].grade-grade`);
    const courseId = document.getElementById('gradeCourse')?.value;
    const examType = document.getElementById('gradeExam')?.value;
    
    const score = scoreInput?.value;
    const grade = gradeSelect?.value;
    
    if (!score || !grade || !courseId || !examType) {
        showToast('Please fill all fields! | برائے مہربانی سب فیلڈ پر کریں!', 'warning');
        return;
    }
    
    schoolData.grades.push({
        id: generateId('GRD'),
        studentId,
        courseId,
        examType,
        score: parseInt(score),
        grade,
        date: new Date().toISOString().split('T')[0]
    });
    
    saveDataToStorage();
    showToast('Grade saved! | نمبرات محفوظ!', 'success');
}

function markFeePaid(id) {
    const fee = schoolData.fees.find(f => f.id === id);
    if (fee) {
        fee.status = 'paid';
        fee.paidDate = new Date().toISOString().split('T')[0];
        saveDataToStorage();
        
        addActivity('💰', `Fee paid by student`);
        renderFeesSection();
        showToast('Fee marked as paid! | فیس ادا ہو گئی!', 'success');
    }
}

function deleteFee(id) {
    if (confirm('Delete this fee record? | اس فیس ریکارڈ کو حذف کریں؟')) {
        schoolData.fees = schoolData.fees.filter(f => f.id !== id);
        saveDataToStorage();
        renderFeesSection();
        showToast('Fee record deleted! | فیس ریکارڈ حذف ہو گیا!', 'error');
    }
}

function editStudent(id) {
    const student = schoolData.students.find(s => s.id === id);
    if (student) {
        openModal('studentModal', 'Edit Student | طالب علم میں ترمیم کریں');
        
        document.getElementById('studentName').value = student.name;
        document.getElementById('studentEmail').value = student.email;
        document.getElementById('studentPhone').value = student.phone;
        document.getElementById('studentClass').value = student.class;
        document.getElementById('studentCity').value = student.city || '';
        
        // Change form handler
        const form = document.getElementById('studentForm');
        form.onsubmit = function(e) {
            e.preventDefault();
            student.name = document.getElementById('studentName').value;
            student.email = document.getElementById('studentEmail').value;
            student.phone = document.getElementById('studentPhone').value;
            student.class = document.getElementById('studentClass').value;
            student.city = document.getElementById('studentCity').value;
            
            saveDataToStorage();
            closeModal(document.getElementById('studentModal'));
            renderStudentsTable();
            showToast('Student updated! | طالب علم کی معلومات تبدیل!', 'success');
        };
    }
}

function deleteStudent(id) {
    if (confirm('Are you sure you want to delete this student? | کیا آپ اس طالب علم کو حذف کرنا چاہتے ہیں؟')) {
        schoolData.students = schoolData.students.filter(s => s.id !== id);
        saveDataToStorage();
        addActivity('🗑️', 'Student removed | طالب علم حذف');
        renderStudentsTable();
        populateDropdowns();
        updateAllStats();
        showToast('Student deleted! | طالبعلم حذف!', 'error');
    }
}

function editTeacher(id) {
    const teacher = schoolData.teachers.find(t => t.id === id);
    if (teacher) {
        openModal('teacherModal', 'Edit Teacher | استاد میں ترمیم کریں');
        
        document.getElementById('teacherName').value = teacher.name;
        document.getElementById('teacherEmail').value = teacher.email;
        document.getElementById('teacherSubject').value = teacher.subject;
        document.getElementById('teacherPhone').value = teacher.phone;
        
        const form = document.getElementById('teacherForm');
        form.onsubmit = function(e) {
            e.preventDefault();
            teacher.name = document.getElementById('teacherName').value;
            teacher.email = document.getElementById('teacherEmail').value;
            teacher.subject = document.getElementById('teacherSubject').value;
            teacher.phone = document.getElementById('teacherPhone').value;
            
            saveDataToStorage();
            closeModal(document.getElementById('teacherModal'));
            renderTeachersTable();
            showToast('Teacher updated! | استاد کی معلومات تبدیل!', 'success');
        };
    }
}

function deleteTeacher(id) {
    if (confirm('Are you sure you want to delete this teacher? | کیا آپ اس استاد کو حذف کرنا چاہتے ہیں؟')) {
        schoolData.teachers = schoolData.teachers.filter(t => t.id !== id);
        saveDataToStorage();
        addActivity('🗑️', 'Teacher removed | استاد حذف');
        renderTeachersTable();
        populateDropdowns();
        updateAllStats();
        showToast('Teacher deleted! | استاد حذف!', 'error');
    }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function generateId(prefix) {
    return prefix + String(schoolData[`${prefix.toLowerCase().slice(0, -1)}s`]?.length + 1 || 1).padStart(3, '0');
}

function addActivity(icon, text) {
    schoolData.activities.unshift({
        icon,
        text,
        time: 'ابھی | Just now'
    });
    schoolData.activities = schoolData.activities.slice(0, 10);
    saveDataToStorage();
}

function populateDropdowns() {
    // Courses for grades
    const gradeCourse = document.getElementById('gradeCourse');
    if (gradeCourse && gradeCourse.options.length <= 1) {
        gradeCourse.innerHTML = '<option value="">Select Course | کورس select کریں</option>';
        schoolData.courses.forEach(c => {
            gradeCourse.innerHTML += `<option value="${c.id}">${c.name}</option>`;
        });
    }
    
    // Courses for schedule
    const scheduleCourse = document.getElementById('scheduleCourse');
    if (scheduleCourse && scheduleCourse.options.length <= 1) {
        scheduleCourse.innerHTML = '<option value="">Select Course | کورس select کریں</option>';
        schoolData.courses.forEach(c => {
            scheduleCourse.innerHTML += `<option value="${c.id}">${c.name}</option>`;
        });
    }
    
    // Teachers for courses
    const courseTeacher = document.getElementById('courseTeacher');
    if (courseTeacher && courseTeacher.options.length <= 1) {
        courseTeacher.innerHTML = '<option value="">Select Teacher | استاد select کریں</option>';
        schoolData.teachers.forEach(t => {
            courseTeacher.innerHTML += `<option value="${t.id}">${t.name}</option>`;
        });
    }
    
    // Students for fees
    const feeStudent = document.getElementById('feeStudent');
    if (feeStudent && feeStudent.options.length <= 1) {
        feeStudent.innerHTML = '<option value="">Select Student | طالب علم select کریں</option>';
        schoolData.students.forEach(s => {
            feeStudent.innerHTML += `<option value="${s.id}">${s.name} (${s.id})</option>`;
        });
    }
    
    // Classes for attendance
    const attendanceClass = document.getElementById('attendanceClass');
    if (attendanceClass && attendanceClass.options.length <= 1) {
        const classes = [...new Set(schoolData.students.map(s => s.class))];
        attendanceClass.innerHTML = '<option value="">Select Class | جماعت select کریں</option>';
        classes.forEach(cls => {
            attendanceClass.innerHTML += `<option value="${cls}">${cls}</option>`;
        });
    }
}

function searchData(term) {
    const results = {
        students: schoolData.students.filter(s => s.name.toLowerCase().includes(term) || s.id.toLowerCase().includes(term)),
        teachers: schoolData.teachers.filter(t => t.name.toLowerCase().includes(term) || t.id.toLowerCase().includes(term)),
        courses: schoolData.courses.filter(c => c.name.toLowerCase().includes(term) || c.code.toLowerCase().includes(term))
    };
    
    console.log('Search results:', results);
    
    // Navigate to students if matches found
    if (results.students.length > 0) {
        navigateToSection('students');
        renderStudentsTable();
    }
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer') || createToastContainer();
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span> <span class="toast-message">${message}</span> <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>`;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'toastSlide 0.4s ease forwards reverse';
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
    return container;
}

// ============================================
// SAMPLE DATA - PAKISTANI SCHOOL
// ============================================

function loadSampleData() {
    if (schoolData.students.length > 0 || schoolData.teachers.length > 0) {
        return; // Data already loaded
    }
    
    // Sample Students
    schoolData.students = [
        { id: 'STU001', name: 'Muhammad Ali Raza', email: 'ali@school.com', phone: '0301-2345678', class: 'Class 9', city: 'Karachi', fatherName: 'Ahmed Raza', admissionDate: '2023-01-15' },
        { id: 'STU002', name: 'Fatima Begum', email: 'fatima@school.com', phone: '0302-3456789', class: 'Class 10', city: 'Lahore', fatherName: 'Muhammad Usman', admissionDate: '2022-03-20' },
        { id: 'STU003', name: 'Hassan Ahmed', email: 'hassan@school.com', phone: '0303-4567890', class: 'Class 8', city: 'Karachi', fatherName: 'Imran Ahmed', admissionDate: '2023-06-10' },
        { id: 'STU004', name: 'Ayesha Malik', email: 'ayesha@school.com', phone: '0304-5678901', class: 'Class 9', city: 'Faisalabad', fatherName: 'Khalid Malik', admissionDate: '2023-02-01' },
        { id: 'STU005', name: 'Omer Farooq', email: 'omer@school.com', phone: '0305-6789012', class: 'Class 7', city: 'Rawalpindi', fatherName: 'Farooq Ali', admissionDate: '2023-04-15' },
        { id: 'STU006', name: 'Zainab Bibi', email: 'zainab@school.com', phone: '0306-7890123', class: 'Class 10', city: 'Multan', fatherName: 'Abdul Qadir', admissionDate: '2022-08-20' },
        { id: 'STU007', name: 'Bilal Khan', email: 'bilal@school.com', phone: '0307-8901234', class: 'Class 8', city: 'Peshawar', fatherName: 'Gul Khan', admissionDate: '2023-01-10' },
        { id: 'STU008', name: 'Saima Noor', email: 'saima@school.com', phone: '0308-9012345', class: 'Class 9', city: 'Karachi', fatherName: 'Noor Muhammad', admissionDate: '2023-03-05' },
        { id: 'STU009', name: 'Ali Hassan', email: 'hassan@school.com', phone: '0309-0123456', class: 'Class 7', city: 'Quetta', fatherName: 'Hassan Ali', admissionDate: '2023-05-20' },
        { id: 'STU010', name: 'Rabia Sultana', email: 'rabia@school.com', phone: '0310-1234567', class: 'Class 10', city: 'Karachi', fatherName: 'Sultan Ahmed', admissionDate: '2022-07-12' }
    ];
    
    // Sample Teachers
    schoolData.teachers = [
        { id: 'TCH001', name: 'Prof. Abdul Qadir', email: 'aqadir@school.com', subject: 'Mathematics', phone: '0321-1112223', qualification: 'M.Sc Mathematics', experience: '15 years' },
        { id: 'TCH002', name: 'Dr. Rabia Sultana', email: 'rsultana@school.com', subject: 'Physics', phone: '0322-2223334', qualification: 'Ph.D Physics', experience: '12 years' },
        { id: 'TCH003', name: 'Sir Muhammad Asif', email: 'masif@school.com', subject: 'Urdu', phone: '0323-3334445', qualification: 'M.A Urdu', experience: '10 years' },
        { id: 'TCH004', name: 'Ms. Fatima Noor', email: 'fnoor@school.com', subject: 'English', phone: '0324-4445556', qualification: 'M.A English', experience: '8 years' },
        { id: 'TCH005', name: 'Maulana Tariq Mehmood', email: 'tariq@school.com', subject: 'Islamiyat', phone: '0325-5556667', qualification: 'Alim, M.A Islamiyat', experience: '20 years' },
        { id: 'TCH006', name: 'Dr. Noman Siddiqui', email: 'nsiddiqui@school.com', subject: 'Chemistry', phone: '0326-6667778', qualification: 'Ph.D Chemistry', experience: '11 years' },
        { id: 'TCH007', name: 'Sir Jamil Ahmed', email: 'jamil@school.com', subject: 'Pakistan Studies', phone: '0327-7778889', qualification: 'M.A History', experience: '14 years' },
        { id: 'TCH008', name: 'Ms. Saima Riaz', email: 'sriaz@school.com', subject: 'Computer Science', phone: '0328-8889990', qualification: 'MCS', experience: '6 years' },
        { id: 'TCH009', name: 'Sir Imtiaz Khan', email: 'imtiaz@school.com', subject: 'Biology', phone: '0329-9990001', qualification: 'M.Sc Biology', experience: '9 years' },
        { id: 'TCH010', name: 'Prof. Ayesha Khan', email: 'akhan@school.com', subject: 'Mathematics', phone: '0330-0001112', qualification: 'M.Sc Mathematics', experience: '13 years' }
    ];
    
    // Sample Courses
    schoolData.courses = [
        { id: 'CRS001', name: 'Mathematics | ریاضی', code: 'MATH101', teacherId: 'TCH001', credits: 4, classLevel: 'Class 9-10' },
        { id: 'CRS002', name: 'Physics | فزکس', code: 'PHY101', teacherId: 'TCH002', credits: 4, classLevel: 'Class 9-10' },
        { id: 'CRS003', name: 'Urdu Grammar | اردو', code: 'URD101', teacherId: 'TCH003', credits: 3, classLevel: 'Class 7-10' },
        { id: 'CRS004', name: 'English Literature | انگلش', code: 'ENG201', teacherId: 'TCH004', credits: 3, classLevel: 'Class 7-10' },
        { id: 'CRS005', name: 'Islamiyat | اسلامیات', code: 'ISL101', teacherId: 'TCH005', credits: 2, classLevel: 'Class 7-10' },
        { id: 'CRS006', name: 'Chemistry | کیمسٹری', code: 'CHEM101', teacherId: 'TCH006', credits: 4, classLevel: 'Class 9-10' },
        { id: 'CRS007', name: 'Pakistan Studies | پاکستانی مطالعہ', code: 'PKS201', teacherId: 'TCH007', credits: 2, classLevel: 'Class 9-10' },
        { id: 'CRS008', name: 'Computer Science | کمپیوٹر', code: 'CS101', teacherId: 'TCH008', credits: 3, classLevel: 'Class 7-10' },
        { id: 'CRS009', name: 'Biology | بایولوجی', code: 'BIO101', teacherId: 'TCH009', credits: 4, classLevel: 'Class 9-10' },
        { id: 'CRS010', name: 'Additional Mathematics | اضافی ریاضی', code: 'MATH201', teacherId: 'TCH010', credits: 4, classLevel: 'Class 10' }
    ];
    
    // Sample Schedules
    schoolData.schedules = [
        { id: 'SCH001', day: 'Monday', time: '08:00', courseId: 'CRS001', room: 'Room 101', class: 'Class 9' },
        { id: 'SCH002', day: 'Monday', time: '09:30', courseId: 'CRS002', room: 'Lab A', class: 'Class 9' },
        { id: 'SCH003', day: 'Monday', time: '11:00', courseId: 'CRS003', room: 'Room 102', class: 'Class 9' },
        { id: 'SCH004', day: 'Tuesday', time: '08:00', courseId: 'CRS004', room: 'Room 103', class: 'Class 9' },
        { id: 'SCH005', day: 'Tuesday', time: '09:30', courseId: 'CRS005', room: 'Room 104', class: 'Class 9' },
        { id: 'SCH006', day: 'Tuesday', time: '11:00', courseId: 'CRS006', room: 'Lab B', class: 'Class 9' },
        { id: 'SCH007', day: 'Wednesday', time: '08:00', courseId: 'CRS001', room: 'Room 101', class: 'Class 9' },
        { id: 'SCH008', day: 'Wednesday', time: '09:30', courseId: 'CRS007', room: 'Room 102', class: 'Class 9' },
        { id: 'SCH009', day: 'Wednesday', time: '11:00', courseId: 'CRS008', room: 'Computer Lab', class: 'Class 9' },
        { id: 'SCH010', day: 'Thursday', time: '08:00', courseId: 'CRS002', room: 'Lab A', class: 'Class 9' },
        { id: 'SCH011', day: 'Thursday', time: '09:30', courseId: 'CRS003', room: 'Room 102', class: 'Class 9' },
        { id: 'SCH012', day: 'Thursday', time: '11:00', courseId: 'CRS009', room: 'Lab C', class: 'Class 9' },
        { id: 'SCH013', day: 'Friday', time: '08:00', courseId: 'CRS005', room: 'Room 101', class: 'Class 9' },
        { id: 'SCH014', day: 'Friday', time: '09:30', courseId: 'CRS004', room: 'Room 103', class: 'Class 9' },
        { id: 'SCH015', day: 'Friday', time: '11:00', courseId: 'CRS006', room: 'Lab B', class: 'Class 9' }
    ];
    
    // Sample Fees (in PKR)
    schoolData.fees = [
        { id: 'INV001', studentId: 'STU001', amount: 5000, dueDate: '2024-02-15', feeType: 'tuition', status: 'paid', paidDate: '2024-02-10' },
        { id: 'INV002', studentId: 'STU002', amount: 5500, dueDate: '2024-02-15', feeType: 'tuition', status: 'pending' },
        { id: 'INV003', studentId: 'STU003', amount: 5000, dueDate: '2024-01-30', feeType: 'tuition', status: 'overdue' },
        { id: 'INV004', studentId: 'STU004', amount: 6000, dueDate: '2024-02-20', feeType: 'annual', status: 'paid', paidDate: '2024-02-18' },
        { id: 'INV005', studentId: 'STU005', amount: 5500, dueDate: '2024-02-15', feeType: 'tuition', status: 'pending' },
        { id: 'INV006', studentId: 'STU006', amount: 5000, dueDate: '2024-02-28', feeType: 'tuition', status: 'pending' },
        { id: 'INV007', studentId: 'STU007', amount: 6000, dueDate: '2024-01-25', feeType: 'exam', status: 'overdue' },
        { id: 'INV008', studentId: 'STU008', amount: 5500, dueDate: '2024-02-15', feeType: 'tuition', status: 'paid', paidDate: '2024-02-14' },
        { id: 'INV009', studentId: 'STU009', amount: 5000, dueDate: '2024-02-15', feeType: 'tuition', status: 'pending' },
        { id: 'INV010', studentId: 'STU010', amount: 5500, dueDate: '2024-02-15', feeType: 'tuition', status: 'paid', paidDate: '2024-02-12' }
    ];
    
    // Sample Activities
    schoolData.activities = [
        { icon: '👨‍🎓', text: 'New student enrolled: Muhammad Ali Raza | کلاس 9', time: '2 گھنٹے پہلے' },
        { icon: '📝', text: 'Grades uploaded for Mathematics | ریاضی', time: '4 گھنٹے پہلے' },
        { icon: '📅', text: 'Attendance marked for Class 9', time: '5 گھنٹے پہلے' },
        { icon: '💰', text: 'Fee payment received from Ayesha Malik', time: '1 دن پہلے' },
        { icon: '👨‍🏫', text: 'New teacher added: Prof. Ayesha Khan', time: '2 دن پہلے' },
        { icon: '🎓', text: 'Midterm Exam results declared', time: '3 دن پہلے' }
    ];
    
    // Sample Events
    schoolData.events = [
        { text: 'Parent-Teacher Meeting | والدین کی میٹنگ', date: 'Feb 20, 2024' },
        { text: 'Science Fair | سائنس میلا', date: 'Feb 25, 2024' },
        { text: 'Midterm Exams | وسطی امتحانات', date: 'Mar 1-5, 2024' },
        { text: 'Sports Day | کھیلوں کا دن', date: 'Mar 15, 2024' },
        { text: 'Eid-ul-Fitr Holidays | عید کی چھٹیاں', date: 'Mar 20-25, 2024' },
        { text: 'Annual Day | سالانہ تقریب', date: 'Apr 5, 2024' }
    ];
    
    // Sample Grades
    schoolData.grades = [
        { studentId: 'STU001', courseId: 'CRS001', examType: 'midterm', score: 85, grade: 'A', date: '2024-01-20' },
        { studentId: 'STU001', courseId: 'CRS002', examType: 'midterm', score: 78, grade: 'B+', date: '2024-01-20' },
        { studentId: 'STU002', courseId: 'CRS001', examType: 'midterm', score: 92, grade: 'A+', date: '2024-01-20' },
        { studentId: 'STU003', courseId: 'CRS001', examType: 'midterm', score: 88, grade: 'A', date: '2024-01-20' },
        { studentId: 'STU004', courseId: 'CRS002', examType: 'midterm', score: 75, grade: 'B', date: '2024-01-20' }
    ];
    
    // Save initial attendance for today
    const today = new Date().toISOString().split('T')[0];
    schoolData.students.forEach(student => {
        const randomStatus = Math.random() > 0.2 ? 'present' : (Math.random() > 0.5 ? 'absent' : 'late');
        schoolData.attendance.push({
            studentId: student.id,
            date: today,
            status: randomStatus
        });
    });
    
    saveDataToStorage();
}
